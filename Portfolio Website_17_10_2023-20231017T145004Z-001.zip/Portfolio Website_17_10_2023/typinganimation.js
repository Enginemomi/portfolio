const typingSpeed = 100; // Speed in milliseconds between each character
const iconTypingSpeed = 300; // Speed in milliseconds between each icon
const loopDelay = 2500; // 2.5 seconds

const typingText = document.getElementById("typing-text");
const text = "Welcome to my portfolio!!!";
let charIndex = 0;

function typeText() {
    if (charIndex < text.length) {
        typingText.textContent += text.charAt(charIndex);
        charIndex++;
        setTimeout(typeText, typingSpeed);
    } else {
        animateIcons(); // Start icon typing animation
        setInterval(animateIcons, iconTypingSpeed * 8 + loopDelay); // Start animation loop
    }
}

function createIcon(iconName, fontSize) {
    const icon = document.createElement("i");
    icon.className = "material-icons";
    icon.style.fontSize = `${fontSize}px`;
    icon.style.color = "#89CFF0";
    icon.textContent = iconName;
    icon.style.opacity = 0; // Initialize opacity to 0 for animation
    return icon;
}

function animateIcons() {
    const iconContainer = document.createElement("div"); // Create the icon container
    iconContainer.className = "icon-container";
    iconContainer.style.display = "inline-block"; // Display icons inline

    const cloudIcon1 = createIcon("cloud", 20);
    const cloudIcon2 = createIcon("cloud", 22);
    const cloudIcon3 = createIcon("cloud", 24);
    const cloudIcon4 = createIcon("cloud", 26);
    const cloudIcon5 = createIcon("cloud", 28);
    const cloudIcon6 = createIcon("cloud", 30);
    const cloudIcon7 = createIcon("cloud", 32);
    const cloudIcon8 = createIcon("cloud", 34);

    const textNode = document.createTextNode("Welcome to my portfolio!!! ");
    typingText.textContent = ""; // Clear existing text
    typingText.appendChild(textNode);
    typingText.appendChild(iconContainer); // Add icon container after the text

    iconContainer.appendChild(cloudIcon1);
    iconContainer.appendChild(cloudIcon2);
    iconContainer.appendChild(cloudIcon3);
    iconContainer.appendChild(cloudIcon4);
    iconContainer.appendChild(cloudIcon5);
    iconContainer.appendChild(cloudIcon6);
    iconContainer.appendChild(cloudIcon7);
    iconContainer.appendChild(cloudIcon8);

    const icons = iconContainer.querySelectorAll(".material-icons");
    icons.forEach((icon, index) => {
        setTimeout(() => {
            icon.style.opacity = 1;
        }, index * iconTypingSpeed);
    });

    setTimeout(() => {
        iconContainer.remove(); // Remove the icon container after animation
    }, icons.length * iconTypingSpeed + loopDelay); // Adjust the timing as needed
}

typeText();
