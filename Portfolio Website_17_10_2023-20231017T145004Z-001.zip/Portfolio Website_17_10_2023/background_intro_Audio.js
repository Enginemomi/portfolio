document.addEventListener("DOMContentLoaded", function() {
    const audioLink = document.getElementById("audioLink");
    const backgroundAudio = document.getElementById("backgroundAudio");
    const audioIcon = document.getElementById("audioIcon");

    audioLink.addEventListener("click", function(event) {
        event.preventDefault();
        if (backgroundAudio.paused) {
            backgroundAudio.play();
            audioIcon.textContent = "volume_up"; // Change the icon to "volume_up" when audio is playing
        } else {
            backgroundAudio.pause();
            audioIcon.textContent = "volume_off"; // Change the icon to "volume_off" when audio is paused
        }
    });
});
