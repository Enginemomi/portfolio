// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        // Get the target element using the href attribute
        const targetElement = document.querySelector(this.getAttribute('href'));

        // Calculate the offset for scrolling to consider fixed headers
        const offset = targetElement.getBoundingClientRect().top + window.scrollY;

        // Scroll to the target element with smooth behavior
        window.scrollTo({
            top: offset,
            behavior: 'smooth'
        });
    });
});
